package com.example.cauroselapp

class News(
    val totalResults: Int,
    val articles : List<Articles>
)