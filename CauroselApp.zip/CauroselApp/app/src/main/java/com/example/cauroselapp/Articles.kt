package com.example.cauroselapp

class Articles(

    val urlToImage: String,
    val title:String,
    val description: String,
    val url:String
)